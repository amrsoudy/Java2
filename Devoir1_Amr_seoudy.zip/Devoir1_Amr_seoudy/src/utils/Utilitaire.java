package utils;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

import model.Client;
import model.Hypo;

public class Utilitaire {

    public static void saisierInfo(Hypo hypo) throws MonException, NumberFormatException {
        boolean flag = true;

        double mount, taux = 0;
        int anne = 0;

        while (flag) {
            try {
                taux = ((Double.parseDouble(javax.swing.JOptionPane.showInputDialog("Sasir le taux SVP "))));
                if (taux <= 0) {

                    throw new MonException("le taux dois etre positive Svp");
                } else {
                    hypo.setTaux(taux);
                    flag = false;

                }
            } catch (MonException m) {
                javax.swing.JOptionPane.showMessageDialog(null, m.getMessage());

            } catch (NumberFormatException n) {

                javax.swing.JOptionPane.showMessageDialog(null, "dois etre numeric et pas vide ");

            }
        }
        while (!flag) {
            try {

                Object[] possibleValues = {"5", "10", "15", "20", "30"};
                Object selectedValue = JOptionPane.showInputDialog(null,
                        "Choose one", "Input",
                        JOptionPane.INFORMATION_MESSAGE, null,
                        possibleValues, possibleValues[0]);
                anne = Integer.parseInt(selectedValue.toString());

                if (anne <= 0) {

                    throw new MonException("l'anne dois etre positive Svp");

                } else if ((anne != 5) && (anne != 10) && (anne != 15) && (anne != 20) && (anne != 30)) {
                    throw new MonException("l'anne dois  etre 5 ,10,15,20 et 30 seulement");

                } else {
                    hypo.setAnnee(anne);
                    flag = true;

                }
            } catch (MonException m) {
                javax.swing.JOptionPane.showMessageDialog(null, m.getMessage());

            } catch (NumberFormatException n) {

                javax.swing.JOptionPane.showMessageDialog(null, "dois etre numeric et pas vide ");

            }
        }
        while (flag == true) {
            try {
                mount = (Double.parseDouble(javax.swing.JOptionPane.showInputDialog(null, "Combien le mountant SVP")));
                if (mount <= 0) {

                    throw new MonException("l'mountant dois etre positive Svp");
                } else {
                    hypo.setMountant(mount);
                    flag = false;

                }
            } catch (MonException m) {
                javax.swing.JOptionPane.showMessageDialog(null, m.getMessage());

            } catch (NumberFormatException n) {
                javax.swing.JOptionPane.showMessageDialog(null, "dois etre numeric et pas vide ");

            }
        }

    }

    public static double calculMap(Client c) {
        double tim = (c.getHypo().getTaux() / 12);
        double map = 0;

        map = (tim * c.getHypo().getMountant()) / (1 - (1 / (fab((1 + tim), 12 * c.getHypo().getAnnee()))));

        c.getHypo().setMapList(map);
        return map;

    }

    public static double fab(double mont, int combien) {
        double somme = 1;
        //si je commance de 0 donc < combien  pas  < = compain
        for (int i = 0; i < combien; i++) {
            somme = mont * somme;

        }

        return somme;

    }

    public static void Affichage(Client c) {

        javax.swing.JOptionPane.showMessageDialog(null,
                "the rate is  : " + c.getHypo().getTaux() * 100 + " %" + " and the number of years is  :   "
                + c.getHypo().getAnnee() + "  et la montant emprunte est :  " + c.getHypo().getMountant()
                + " $ ");

        DecimalFormat df = new DecimalFormat("#.##");
        for (double i : c.getHypo().getMapList()) {
            javax.swing.JOptionPane.showMessageDialog(null, ("le mountant Mansual est : " + (df.format(i) + " $")));

        }
        javax.swing.JOptionPane.showMessageDialog(null, ("le mountant Total en fin : "
                + (df.format((Utilitaire.calculMap(c)) * (c.getHypo().getAnnee() * 12)) + " $")));
        ;

    }

}
