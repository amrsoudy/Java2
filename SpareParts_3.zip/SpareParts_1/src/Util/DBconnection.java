/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author AMR
 */
public class DBconnection {

    private Connection con;
    private Statement st;
    private ResultSet rs;

    public DBconnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parts", "root", "");
            st = con.createStatement();

        } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }

    public void getData(String query) {

        try {

            rs = st.executeQuery(query);
            while (rs.next()) {

                String name = rs.getString("user");
                String pass = rs.getString("pass");
                String position = rs.getString("position");

                System.out.println("Username " + name + "pass " + pass + "position" + position);

            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, ex.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);

        }

    }

    public void theQuery(String query) {

        try {
             st.executeUpdate(query);
             JOptionPane.showMessageDialog(null,"query excuted");
            

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e.getMessage(), "Errorinsert", JOptionPane.ERROR_MESSAGE);

        }
    }
}
