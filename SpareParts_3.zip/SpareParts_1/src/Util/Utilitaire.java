package Util;

import modul.Machines;
import modul.Parts;
import java.util.ArrayList;
import java.util.function.Supplier;

public  class Utilitaire {

    ArrayList<Parts> listParts = new ArrayList<>();
    ArrayList<Machines> listMachines = new ArrayList<>();
    ArrayList<Supplier> listSuppliers = new ArrayList<>();

    public ArrayList<Parts> getListParts() {
        return listParts;
    }


    public ArrayList<Machines> getListMachines() {
        return listMachines;
    }

  

    public ArrayList<Supplier> getListSuppliers() {
        return listSuppliers;
    }

  

}
