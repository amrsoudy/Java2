/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul;

import java.util.*;

/**
 *
 * @author AMR
 */
public class Parts {
    private int partId;
    private String partName ; 
    private String partDesc ;
    private double prix ; 
    private String supplierName;
    private String machineName ;
     private int quantity ;
     private Date creationDate ;
    private String imagePath;

    public Parts(int partId, String partName, String partDesc, double prix, String supplierName, String machineName, int quantity, Date creationDate) {
        this.partId = partId;
        this.partName = partName;
        this.partDesc = partDesc;
        this.prix = prix;
        this.supplierName = supplierName;
        this.machineName = machineName;
        this.quantity = quantity;
        this.creationDate = creationDate;
        this.imagePath = imagePath;
    }



    @Override
    public String toString() {
        return "Parts{" + partId + ", partName=" + partName + ", partDesc=" + partDesc + ", prix=" + prix + ", supplierName=" + supplierName + ", machineName=" + machineName + ", quantity=" + quantity + ", imagePath=" + imagePath + '}';
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartDesc() {
        return partDesc;
    }

    public void setPartDesc(String partDesc) {
        this.partDesc = partDesc;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    
    
    
    
    
    
}
