package Control;

import util.EmployeDejaPresentException;
import Modele.Employee;
import Modele.ListEmployee;
import Vue.GuiSimple;
import javax.swing.JFrame;

public class Appctr {

    public static void main(String[] args) {

        int WIDTH = 400, HEIGHT = 300;

        GuiSimple objGui = new GuiSimple();
        objGui.run();
        objGui.setSize(WIDTH, HEIGHT);
        objGui.setLocationRelativeTo(null);
        objGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        objGui.setVisible(true);


        

    }

}
