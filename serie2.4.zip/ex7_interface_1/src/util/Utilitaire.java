/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import Modele.Employee;
import Modele.ListEmployee;
import java.util.Iterator;
import javax.swing.JOptionPane;

/**
 *
 * @author AMR
 */
public class Utilitaire {

    private ListEmployee list1 = new ListEmployee();

    public void ajouterEmployee(Employee emp) {

        try {

            if (isdublicate(emp) == false) {
                              
                    list1.getEmplist().add(emp);
                    JOptionPane.showMessageDialog(null, "Employe Ajouté avec succés", "Confirmation", JOptionPane.INFORMATION_MESSAGE);

                

            } else {

                throw new EmployeDejaPresentException("Employé déjà présent avec !" + emp.getNom());

            }
        }catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Tu peux pas ajoute vide information", "Alerte", JOptionPane.ERROR_MESSAGE);
        }catch (EmployeDejaPresentException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Alerte", JOptionPane.ERROR_MESSAGE);
        } 

    }

    public void listerEmployee() {
        String message = "\n list d'employee\n";
        for (Employee e : list1.getEmplist()) {
            message += "\n\n\n" + "Nom:  " + e.getNom() + "   prenom: " + e.getPrenom()+"   Age :  "+e.getAge();



        }
                   JOptionPane.showMessageDialog(null, message);


    }

    public boolean isdublicate(Employee emp) {

        Iterator iterateur = list1.getEmplist().iterator();
        Employee empCourant;
        while (iterateur.hasNext()) {
            empCourant = (Employee) iterateur.next();
            if (emp.equals(empCourant)) {
                return true;
            }

        }
        return false;
    }
    

}
