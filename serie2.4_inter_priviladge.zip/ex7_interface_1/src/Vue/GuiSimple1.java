package Vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javafx.scene.text.Font;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.UIManager;
import util.Utilitaire;

/**
 *
 * @author 1795162
 */
public class GuiSimple1 extends JFrame {

    private JLabel label;
    private JButton convert;
    private JButton quitter;
    private JTextField text1 = new JTextField();

    public JTextField getText1() {
        return text1;
    }

    public void setText1(JTextField text1) {
        this.text1 = text1;
    }
    private JPasswordField  text2 = new JPasswordField (10);
    Utilitaire util1 = new Utilitaire();

    public void setDefaultCloseOperation(int operation) {
        super.setDefaultCloseOperation(operation); //To change body of generated methods, choose Tools | Templates.
    }

    public GuiSimple1() {

    }

    public void run() {

        JPanel panelGlobal = new JPanel();

        BorderLayout bd = new BorderLayout();
        panelGlobal.setLayout(bd);

        JPanel pButton = new JPanel();

        JButton connect = new JButton("Connect");
        JButton quit = new JButton("Quiter");

        pButton.add(connect);
        pButton.add(quit);

        quit.addActionListener(new quiterListner());
        connect.addActionListener(new ActionListner());
        panelGlobal.add(pButton, bd.SOUTH);

        JPanel p1 = new JPanel();
        JPanel p2 = new JPanel();
        JPanel p3 = new JPanel();
        JPanel p4 = new JPanel();

        text1.setColumns(10);
        JLabel label1 = new JLabel("User Name:    ");
        p2.add(label1);
        p2.add(text1);

        text2.setForeground(Color.DARK_GRAY);
        JLabel label2 = new JLabel("Password:");
        p3.add(label2);
        p3.add(text2);

        Border bord = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
        p1.setBorder(bord);

        p1.add(p2);
        p1.add(p3);

        JLabel img = new JLabel(new ImageIcon(this.getClass().getResource("/images/wizard.jpg")));
        panelGlobal.add(p1, bd.CENTER);
        panelGlobal.add(img, bd.WEST);

        this.setContentPane(panelGlobal);
        this.setResizable(false);

    }

    private class ActionListner implements ActionListener {

        public ActionListner() {
        }

        public void actionPerformed(ActionEvent e) {
                            inter inter = new inter();


            if ((("AMR".equals(text1.getText().toUpperCase())) && ("000000".equals(text2.getText())))) {
                inter.setLocationRelativeTo(null);
                inter.setSize(700, 500);
                inter.AssignMenu("AMR");

                inter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                inter.setVisible(true);
          
                GuiSimple1.this.setVisible(false);
            }else if ((("MARC".equals(text1.getText().toUpperCase()))&& ("000000".equals(text2.getText())))) {
 inter.setLocationRelativeTo(null);
                inter.setSize(700, 500);
                inter.AssignMenu("MARC");

                inter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                inter.setVisible(true);
          
                GuiSimple1.this.setVisible(false);

            } else {
                ImageIcon icon = new ImageIcon(this.getClass().getResource("/images/angry1.jpg"));

                String str = text1.getText() + "....Ton Usernmae Ou Pass pas correct";
                str.toUpperCase();

                UIManager um = new UIManager();
                um.put("OptionPane.messageForeground", Color.red);
                um.put("Panel.background", Color.darkGray);
                um.put("Panel.background", Font.font(str, WIDTH));

                JOptionPane.showMessageDialog(
                        null,
                        str, "Authontication", JOptionPane.ERROR_MESSAGE,
                        icon);

                text1.setText("");
                text2.setText("");
            }

        }
    }

    private class quiterListner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            System.exit(0);

        }
    }
    

}
