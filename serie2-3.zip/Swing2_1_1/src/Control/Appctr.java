/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Vue.GuiSimple;
import javax.swing.JFrame;

/**
 *
 * @author 1795162
 */
public class Appctr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int WIDTH = 500 , HEIGHT = 300 ;
        
        GuiSimple objGui = new GuiSimple();
        objGui.run();
        objGui.setSize(WIDTH,HEIGHT);
        objGui.setLocationRelativeTo(null);
        objGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        objGui.setVisible(true);
 
        
        // TODO code application logic here
    }
    
}
