package utils;

public class MonException extends Exception{
	
	public MonException(){
		
		
		
	}
	

	public MonException(String message){
		
		super(message);
		
		
	}

}
