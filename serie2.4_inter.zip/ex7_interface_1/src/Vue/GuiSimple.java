/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Modele.Employee;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.JOptionPane;
import util.Utilitaire;
import util.MonException;


/**
 *
 * @author 1795162
 */
public class GuiSimple extends JFrame {

    private JLabel label;
    private JButton convert;
    private JButton quitter;
    private JTextField text1 = new JTextField();
    private JTextField text2 = new JTextField();
    private JTextField text3 = new JTextField();
    Utilitaire util1 = new Utilitaire();

    public void setDefaultCloseOperation(int operation) {
        super.setDefaultCloseOperation(operation); //To change body of generated methods, choose Tools | Templates.
    }

    public GuiSimple() {

    }

    public void run() {
        JPanel panelGlobal = new JPanel();

        BorderLayout bd = new BorderLayout();
        panelGlobal.setLayout(bd);

        JPanel pButton = new JPanel();
        JButton convertie = new JButton("Ajouter");
        convertie.addActionListener(new ajouterListener());

        JButton quit = new JButton("Quiter");
        JButton lister = new JButton("Lister Employee");

        pButton.add(convertie);
        pButton.add(quit);
        pButton.add(lister);

        quit.addActionListener(new quiterListner());
        lister.addActionListener(new ActionListner());
        panelGlobal.add(pButton, bd.SOUTH);

        JPanel p1 = new JPanel();
        JPanel p2 = new JPanel();
        JPanel p3 = new JPanel();
        JPanel p4 = new JPanel();

        text1.setColumns(10);
        JLabel label1 = new JLabel("name:    ");
        p2.add(label1);
        p2.add(text1);

        text2.setColumns(10);
        JLabel label2 = new JLabel("prénom:");
        p3.add(label2);
        p3.add(text2);

        text3.setColumns(10);
        JLabel label3 = new JLabel("Age:       ");
        p4.add(label3);
        p4.add(text3);

        Border bord = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
        p1.setBorder(bord);

        p1.add(p2);
        p1.add(p3);
        p1.add(p4);

        JLabel img = new JLabel(new ImageIcon(this.getClass().getResource("/images/wizard.jpg")));
        panelGlobal.add(p1, bd.CENTER);
        panelGlobal.add(img, bd.WEST);

        this.setContentPane(panelGlobal);
        this.setResizable(false);

    }

    private class ActionListner implements ActionListener {

        public ActionListner() {
        }

        public void actionPerformed(ActionEvent e) {
            util1.listerEmployee();

        }
    }

    private class ajouterListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            try {
                if (("".equals(text1.getText())) || ("".equals(text2.getText())) || ("".equals(text3.getText()))) {
                    throw new NumberFormatException("les Fields dois pas Etre Vide");
           

                } else {

                    Employee emp = new Employee();
                    emp.setNom(text1.getText());
                    emp.setPrenom(text2.getText());
                    try {
                        if (Integer.parseInt(text3.getText()) <= 0) {
                            throw new MonException("l'age dois etre positive et plus que Zero");

                        } else {
                            emp.setAge(Integer.parseInt(text3.getText()));
                            util1.ajouterEmployee(emp);
                            text1.setText("");
                            text2.setText("");
                            text3.setText("");
                        }
                    } catch (MonException ex) {
                        JOptionPane.showMessageDialog(null, ex.getMessage(), "Alerte", JOptionPane.ERROR_MESSAGE);

                    }
                }
            
            }catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Alerte", JOptionPane.ERROR_MESSAGE);
            }

        }

    }

    private class quiterListner implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            System.exit(0);

        }
    }

}
