package Modele;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import util.EmployeDejaPresentException;

public class ListEmployee {

    ArrayList<Employee> emplist = new ArrayList<>();

    public ArrayList<Employee> getEmplist() {
        return emplist;
    }

    public void setEmplist(ArrayList<Employee> emplist) {
        this.emplist = emplist;
    }

    
}
