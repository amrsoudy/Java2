package Control;

import util.EmployeDejaPresentException;
import Modele.Employee;
import Modele.ListEmployee;
import Vue.GuiSimple;
import Vue.GuiSimple1;
import javax.swing.JFrame;

public class Appctr {

    public static void main(String[] args) {

        int WIDTH = 400, HEIGHT = 300;

        GuiSimple1 objGui1 = new GuiSimple1();
        objGui1.run();
        
        objGui1.setSize(WIDTH, HEIGHT);
        objGui1.setLocationRelativeTo(null);
        objGui1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        objGui1.setVisible(true);


        

    }

}
